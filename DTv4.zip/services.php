<?php
 $services = 
 '	<div class="service_wrapper">
	<div class="service">
		
		<div class="service-block" onclick="location.href=' . "'avia.php'" . ';">
			<div class="service-text">
			<h3 class="service-text text-center"><img height="48" width="48" class="icon" src="img/icons/avia.png" /> Авиабилеты</h3>
			<p class="service-text text-center"> Как покупать авиабилеты онлайн. Где надежно и выгодно приобрести билеты</p>
			</div>
		</div>
		
		<div class="service-block" onclick="location.href=' . "'hotel.php'" . ';">
			<div class="service-text">
			<h3 class="service-text text-center"><img height="48" width="48" class="icon" src="img/icons/hotel.png" /> Номера в отеле</h3>
			<p class="service-text text-center"> Как бронировать жилье и на что обращать внимание</p>
			</div>
		</div>
		
		<!--<div class="service-block"  onclick="location.href=' . "'car-rent.php'" . ';">
			<div class="service-text">
			<h3 class="service-text text-center"><img height="50" width="50" class="icon" src="img/icons/car-rent.png" /> Аренда машины</h3>
			<p class="service-text text-center"> Выберите понравившееся авто и отправляйтесь на встречу приключениям</p>
			</div>
		</div>-->
		
		<div class="service-block" onclick="location.href=' . "'transfer.php'" . ';">
			<div class="service-text">
			<h3 class="service-text text-center"><img height="48" width="48" class="icon" src="img/icons/transfer.png" /> Трансфер</h3>
			<p class="service-text text-center"> Из аэропорта в отель. Быстро, легко и надежно</p>
			</div>
		</div>
	</div>
	</div>
 '
?>