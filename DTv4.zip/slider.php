<?php
 $slider = '
 <div class="slider">
 
	<div class="slogan">
		<p class="text-center">Путешествия – это сказка.</p>
		<p class="text-center">Что может быть лучше, чем стать её главным героем.</p>
	</div>
    <div class="slide active-slide slide_1" >
	  
        <div class="slider-cont">
          	  
        </div>
		    
    </div>

    <div class="slide slide_2">
	  
        <div class="slider-cont">
          
		</div>

    </div> 
    <div class="slide slide_3">
	  
		<div class="slider-cont">          
            
        </div>
 
    </div> 
</div>
<div class="scroll_down_wrapper">
	<div id="scroll_down" onclick="scrollingDown();">
		<img src="img/arrow-down.png"/>
	</div>
</div>
'

?>